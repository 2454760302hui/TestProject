from Crypto.Random import random

r = random.choice(['dogs', 'cats', 'bears'])
print(r)
