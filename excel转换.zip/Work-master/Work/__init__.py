import pymysql
# 用pymysql来代替默认的mysqldb
pymysql.install_as_MySQLdb()