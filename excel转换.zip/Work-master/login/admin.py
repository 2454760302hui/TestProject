from django.contrib import admin
from login.models import *

# Register your models here.

admin.site.register(Execel)
admin.site.register(UserInfo)
