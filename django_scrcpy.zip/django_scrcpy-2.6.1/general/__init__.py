default_app_config = 'general.apps.GeneralConfig'
